// Play button click

document.querySelectorAll(".play").forEach(btn => {

  btn.addEventListener("click", () => {

    alert("Playing: " + btn.parentElement.querySelector(".name").innerText);

  });

});

// Record button click

document.querySelector(".record-btn").addEventListener("click", () => {

  alert("Recording started...");

});

